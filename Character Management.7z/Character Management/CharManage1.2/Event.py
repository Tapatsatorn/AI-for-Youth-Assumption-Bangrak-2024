from collections import deque

class EventQueue:
    def __init__(self):
        self.events = deque()

    def enqueue(self, event):
        self.events.append(event)
        print(f"Event queued: {event}")

    def dequeue(self):
        if self.events:
            event = self.events.popleft()
            print(f"Event executed: {event}")
            return event
        else:
            print("No events to execute.")
            return None

    def process_events(self):
        while self.events:
            self.dequeue()
