from Action import Action as ActionStack
from Event import EventQueue
import time

class Battle:
    def __init__(self, hero, enemy):
        self.hero = hero
        self.enemy = enemy
        self.action_stack = ActionStack()
        self.event_queue = EventQueue()

    def hero_attack(self):
        damage = 10
        self.enemy.Hitpoint -= damage
        action = f"{self.hero.Name} attacks {self.enemy.Name} for {damage} damage."
        self.action_stack.push(action)
        print(action)

    def hero_use_skill(self, skill_name):
        self.hero.use_skill(skill_name, self.enemy)
        action = f"{self.hero.Name} uses {skill_name} on {self.enemy.Name}."
        self.action_stack.push(action)

    def schedule_heal(self, heal_amount):
        event = lambda: self.hero.heal() if self.hero.Hitpoint < self.hero.Based_HP else None
        self.event_queue.enqueue(event)

    def schedule_enemy_action(self):
        event = lambda: self.enemy_attack()
        self.event_queue.enqueue(event)

    def enemy_attack(self):
        damage = 10
        self.hero.Hitpoint -= damage
        action = f"{self.enemy.Name} attacks {self.hero.Name} for {damage} damage."
        self.action_stack.push(action)
        print(action)

    def process_event_queue(self):
        self.event_queue.process_events()

    def display_action_history(self):
        actions = self.action_stack.get_all_actions()  # Fetch all actions from the stack
        print("Action History:")
        for action in actions:
            print(action)
            with open('log.log', 'at') as file:
                file.write(f'{action} at {time.localtime()} \n')

    def undo_last_action(self):
        last_action = self.action_stack.pop()  # Pop the last action from the stack
        if last_action:
            print(f"Undid action: {last_action}")
        else:
            print("No actions to undo.")

    def start_battle(self):
        self.hero_attack()
        self.hero_use_skill("Fireball")
        self.schedule_heal(10)
        self.schedule_enemy_action()
        self.process_event_queue()
        self.display_action_history()
