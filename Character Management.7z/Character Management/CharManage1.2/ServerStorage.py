from LocalStorage import Skill

class ServerStorage:
    class GlobalSkill:
        def __init__(self, name, damage, xp_per_use):
            self.name = name
            self.damage = damage
            self.xp_per_use = xp_per_use
            
        Fireball = Skill(name='Fireball', damage=45, xp_per_use=10)
        Hit = Skill(name='Hit', damage=10, xp_per_use=0)

    class GlobalEffect:
        Fire = {
            'Name': 'Fire',
            'DamagePerTick': 10,
            'TickInterval': 1.2,
            'Duration': 6.0,
        }

    # Define the skill tree
    skill_tree = {
        "Fireball": {
            "experience": 100,
            "unlocks": ["Firestorm"]
        },
        "Firestorm": {
            "experience": 200,
            "unlocks": ["Inferno"]
        },
        "Inferno": {
            "experience": 300,
            "unlocks": []
        },
        "Hit": {
            "experience": 50,
            "unlocks": []
        }
    }

    @staticmethod
    def calculate_total_experience(skill_name):
        if skill_name not in ServerStorage.skill_tree:
            return 0  # If the skill is not found, return 0

        skill = ServerStorage.skill_tree[skill_name]
        total_experience = skill["experience"]

        # Recursively add experience for all unlocked skills
        for unlocked_skill in skill["unlocks"]:
            total_experience += ServerStorage.calculate_total_experience(unlocked_skill)

        return total_experience


# Example usage of calculating total experience
if __name__ == "__main__":
    total_exp = ServerStorage.calculate_total_experience("Fireball")
    print(f"Total experience needed to unlock Fireball and all its skills: {total_exp}")
