from ServerStorage import ServerStorage
import Character
from Battle import Battle
class Function:
    def __init__(self):
        ...

    def log(self, logs):
        with open('log.log', 'at') as file:
            logs = str(logs)
            file.write(logs)

    def Newchar(self, name):
        self.name = name
        Char = Character.Character(self.name, hitpoint=120)
        Char.add_skill(ServerStorage.GlobalSkill.Hit)
        Cn = Char.Name
        Ch = Char.Hitpoint
        Cb = Char.Based_HP
        Cx = Char.XP
        Cl = Char.Level
        Chps = Char.HealPS
        with open('Character.csv', 'at') as file:
            row = f'{Cn},{Ch},{Cb},{Cx},{Cl},{Chps}\n'
            file.write(row)

        return Char
    
    def start_battle(self, hero_name, enemy_name):
        battle = Battle(hero_name, enemy_name)
        battle.start_battle()

class Child(Function):
    def __init__(self):
        super().__init__()
