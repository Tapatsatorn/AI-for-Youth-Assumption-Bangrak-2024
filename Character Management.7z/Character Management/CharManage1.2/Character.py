import time
import ServerStorage

'''
class Parent:
    def __init__(self, txt):
        self.message = txt

class Child(Parent):
    def __init__(self):
        super().__init__()

        
class Character:
    CName = None
    CBased_HP = 100
    CXP = 0
    CLevel = CXP // 100 #100 XP = 1 Level
    CHitpoint = None
    CHealPS = 2.5 #Heal Per Second

    def __init__(self):
        self.Name = self.CName
        self.Hitpoint = self.CHitpoint
        self.Based_HP = self.CBased_HP
        self.XP = self.CXP
        self.Level = self.CLevel
        self.HealPS = self.CHealPS

'''

class Character:
    def __init__(self, name=None, hitpoint=None):
        self.Name = name if name else "Unknown"
        self.Hitpoint = hitpoint if hitpoint else 100  # Default Hitpoint
        self.Based_HP = 100  # Default base HP
        self.XP = 0
        self.Level = self.XP // 100  # 100 XP = 1 Level
        self.HealPS = 2.5  # Heal Per Second
        self.skills = []  # Initialize an empty list for skills

    def heal(self):
        self.Hitpoint = min(self.Hitpoint + self.HealPS, self.Based_HP)

    def add_skill(self, skill):
        self.skills.append(skill)
        print(f"{self.Name} has learned a new skill: {skill.Name}") 
        with open('log.log', 'at') as file:
            file.write(f"{self.Name} has learned a new skill: {skill.Name}")


    def use_skill(self, skill_name, target_character):
        for skill in self.skills:  # Iterate over the skills
            if skill.Name == skill_name:  # Use dot notation to access 'Name'
                # Assuming you want to deal damage to the target character
                damage = skill.Damage  # Use the Damage attribute of the skill
                target_character.Hitpoint -= damage
                print(f"{self.Name} uses {skill_name} on {target_character.Name} for {damage} damage.")
                return  # Exit after using the skill

        print(f"{self.Name} does not have the skill '{skill_name}'.")

    def gain_xp(self, amount):
        self.XP += amount
        self.Level = self.XP // 100  # Update level based on XP
        print(f"{self.Name} gained {amount} XP! Total XP: {self.XP}. Level: {self.Level}")
        with open('log.log', 'at') as file:
            row = f'{self.Name} gained {amount} at {time.localtime()} \n'
            file.write(row)

