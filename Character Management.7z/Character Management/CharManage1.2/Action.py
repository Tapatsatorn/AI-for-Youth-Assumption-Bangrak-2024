class Action:
    def __init__(self):
        self.actions = []  # This will hold all actions

    def push(self, action):
        self.actions.append(action)  # Add action to the stack

    def pop(self):
        if self.actions:
            return self.actions.pop()  # Remove and return the last action
        return None  # Return None if the stack is empty

    def get_all_actions(self):
        return self.actions  # Return all actions
