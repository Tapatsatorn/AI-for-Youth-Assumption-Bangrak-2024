from ServerStorage import ServerStorage
import time
from Character import Character
from typing import TypeVar

# Create a generic type variable for Character
T = TypeVar('T', bound=Character)

class ServerService:
    @staticmethod
    def apply_fire_effect(target_character: T) -> None:
        effect = ServerStorage.GlobalEffect.Fire
        total_ticks = int(effect['Duration'] / effect['TickInterval'])

        for tick in range(total_ticks):
            ServerService.update_hitpoint(target_character, effect['DamagePerTick'])
            
            if target_character.Hitpoint <= 0:
                print(f"{target_character.Name} has been defeated!")
                break
            
            time.sleep(effect['TickInterval'])

        print("Fire effect has ended.")

    @staticmethod
    def update_hitpoint(target_character: T, damage: int) -> None:
        target_character.Hitpoint -= damage
        print(f"{target_character.Name} takes {damage} damage. Remaining HP: {target_character.Hitpoint}")
