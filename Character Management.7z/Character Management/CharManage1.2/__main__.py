from GlobalFunc import Function
from ServerStorage import ServerStorage

function_instance = Function()

hero = function_instance.Newchar('seigi no hiiro')
enemy = function_instance.Newchar('Bot1')
function_instance.start_battle(hero, enemy)