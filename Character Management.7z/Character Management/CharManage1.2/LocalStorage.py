import Character
'''
class Skill(Character.Character):
    def __init__(self):
        super().__init__()
    Skill1 = {
        'Name' : None,
    }
    Skill2 = {
        'Name' : None,
    }
    Skill3 = {
        'Name' : None,
    }'''

class Skill:
    def __init__(self, name, damage, xp_per_use):
        self.Name = name        
        self.Damage = damage
        self.XPperUse = xp_per_use


    def use(self, target_character):
        target_character.Hitpoint -= self.Damage
        print(f"{target_character.Name} takes {self.Damage} damage from {self.Name}. Remaining HP: {target_character.Hitpoint}")
        #Xp Logic