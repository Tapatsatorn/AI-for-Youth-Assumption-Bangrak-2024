def find_min_max(arr):
    #print(arr)
    if len(arr) == 0:
        return (None, None)
    elif len(arr) == 1:
        return (arr[0], arr[0])

    mid = len(arr) // 2

    left = arr[:mid]
    right = arr[mid:] 

    left_min_max = find_min_max(left)
    right_min_max = find_min_max(right)

    #print(left_min_max, right_min_max)

    if left_min_max[0] < right_min_max[0]:
        new_min = left_min_max[0]
    elif left_min_max[0] >= right_min_max[0]:
        new_min = right_min_max[0]
    else:
        print('input error')
        new_min = None
        return (None, None)
    
    if left_min_max[1] > right_min_max[1]:
        new_max = left_min_max[1]
    elif left_min_max[1] <= right_min_max[1]:
        new_max = right_min_max[1]
    else:
        print('input error')
        new_max = None
        return (None, None)

    return (new_min, new_max)

arr = [3, 5, 1, 9, 6, 8]
print("Output: ", find_min_max(arr))