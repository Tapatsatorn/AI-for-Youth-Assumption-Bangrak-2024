import time

print(f' Loading')
time.sleep(1)
print(f'\033[A Loading .')
time.sleep(1)
print(f'\033[A Loading . .')
time.sleep(1)
print(f'\033[A Loading . . .')
time.sleep(1)