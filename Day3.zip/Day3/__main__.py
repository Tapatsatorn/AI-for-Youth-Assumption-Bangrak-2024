list_elements = [23, 3, 63, 47, 14, 1, 30, 37, 45, 19, 55, 40, 7]

list_elements = sorted(list_elements)

print('sorted: ', list_elements)

def binary_search(arr, target):

    if len(arr) == 0:
        return False
    if len(arr) == 1:
        return arr[0] == target

    print(arr)
    mid = len(arr) // 2

    if arr[mid] == target:
        return True
    elif arr[mid] < target:
        return binary_search(arr[mid:], target)
    else:
        return binary_search(arr[:mid], target)
        
if __name__ == '__main__':
    print(binary_search(list_elements, 19))