# Template code for the "Data Structure Duel"
from redact import *

# Create a contact book using a dictionary
contact_book = {
    'John Doe': (redact(), 'john@example.com'),
    'Jane Smith': ('987-654-3210', 'jane@example.com'),
    'Alice Johnson': ('555-555-5555', 'alice@example.com')
}

# Add contact book for 'John Doe' and the phone Number get from calling function readact() and the email is "john@example.com"
print(contact_book)