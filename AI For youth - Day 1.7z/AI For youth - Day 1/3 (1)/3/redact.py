import http.client

def redact():
    conn = http.client.HTTPConnection("192.168.0.101:5000")
    conn.request("GET", "/3")
    response = conn.getresponse()
    data = response.read()
    conn.close()
    return data.decode('utf-8')
