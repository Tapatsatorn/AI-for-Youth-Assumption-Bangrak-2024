start_x = 0
end_x = 12

i = 0
while i < 13:
  print(i, end='\t')
  N = 0
  while N < 13:
    print(i*N, end='\t')
    N += 1
  i += 1
  print('')
i = 0
while i < 13:
  print(i, end='\t')
  N = 0
  sum = 0
  while N < 13:
    print(sum, end='\t')
    sum += i
    N += 1
  i += 1
  print('')
while i < end_x + 1:
  i += 1
  print(i, end = '\t')
  j = 0
  while j < end_x + 1:
    j += 1
    print(i*j, end = '\t')
    print()