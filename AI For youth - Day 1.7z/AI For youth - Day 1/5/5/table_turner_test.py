# test_table_turner.py

import unittest
from table_turner import generate_multiplication_table

class TestTableTurner(unittest.TestCase):

    def test_multiplication_table(self):
        # Test for the number 5
        expected_output = [
            "5 x 1 = 5",
            "5 x 2 = 10",
            "5 x 3 = 15",
            "5 x 4 = 20",
            "5 x 5 = 25",
            "5 x 6 = 30",
            "5 x 7 = 35",
            "5 x 8 = 40",
            "5 x 9 = 45",
            "5 x 10 = 50"
        ]
        self.assertEqual(generate_multiplication_table(5), expected_output)

    def test_zero(self):
        # Test for the number 0
        expected_output = [
            "0 x 1 = 0",
            "0 x 2 = 0",
            "0 x 3 = 0",
            "0 x 4 = 0",
            "0 x 5 = 0",
            "0 x 6 = 0",
            "0 x 7 = 0",
            "0 x 8 = 0",
            "0 x 9 = 0",
            "0 x 10 = 0"
        ]
        self.assertEqual(generate_multiplication_table(0), expected_output)

if __name__ == "__main__":
    runner = unittest.TextTestRunner()
    result = runner.run(unittest.defaultTestLoader.loadTestsFromTestCase(TestTableTurner))
    
    # Check if the tests passed and print the flag
    if result.wasSuccessful():
        import http.client
        
        conn = http.client.HTTPConnection("192.168.0.101:5000")
        conn.request("GET", "/5")
        response = conn.getresponse()
        data = response.read()
        conn.close()
        print(f'\nAll tests passed! {data}')
