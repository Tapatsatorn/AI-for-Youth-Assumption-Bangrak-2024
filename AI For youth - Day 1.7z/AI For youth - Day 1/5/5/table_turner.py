# table_turner.py

'''
    write a function that return list of string for multiplication table.

    for example

    expected_output = [
        "5 x 1 = 5",
        "5 x 2 = 10",
        "5 x 3 = 15",
        "5 x 4 = 20",
        "5 x 5 = 25",
        "5 x 6 = 30",
        "5 x 7 = 35",
        "5 x 8 = 40",
        "5 x 9 = 45",
        "5 x 10 = 50"
    ]
'''
def generate_multiplication_table(num):
    table = []
    for i in range(1, 11):
        table.append(f"{num} x {i} = {num * i}")
    return table

def print_table(table):
    for line in table:
        print(line)

if __name__ == "__main__":
    # Prompt user for input
    number = int(input("Enter a number for the multiplication table: "))
    
    # Generate the multiplication table
    table = generate_multiplication_table(number)
    
    # Print the formatted table
    print_table(table)
