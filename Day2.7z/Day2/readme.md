AI For Youth 2024 | Assumption Bangrak | Day 2

to test main program:
    1.Go to test.py and write the following code :
*Don't delete the import code
        `virenv.help()`
    2.open terminal and write the following code :
        `py test.py`

to test other program:
    Go to terminal and write the following code :
        `py <filename>`
