import time
import random
import collections

#1
print('#1')
class Character1:
    HP = 100

class Character2:
    HP = 50

Total_HP = Character1.HP + Character2.HP
HP_Difference = Character1.HP - Character2.HP
HP_Product = Character1.HP * Character2.HP
HP_Ratio = Character1.HP / Character2.HP

print(f'Total HP: {Total_HP} \nHP Difference: {HP_Difference} \nHP Product: {HP_Product} \nHP Ratio: {int(Character1.HP/Character2.HP)}:{int(Character2.HP/Character2.HP)}')    
time.sleep(1)

#2
print(f'\n#2')
class Character_2:
    class Naruto:
        Name = 'Naruto'
        attack_power = 95
        energy_level = 89.5

print(f'Character Name : {Character_2.Naruto.Name} \nAttact Power : {Character_2.Naruto.attack_power} \nEnergy Level : {Character_2.Naruto.energy_level}')
time.sleep(1)

#3
print(f'\n#3')
weapons =  ["Sword", "Spear", "Bow", "Axe", "Dagger"]
print('{' + f'"{weapons[3]}", "{weapons[2]}", "{weapons[4]}", "Spears", "{weapons[0]}"' + '}')
time.sleep(1)

#4
print(f'\n#4')
characters = {"Goku": 9000, "Luffy": 5000, "Naruto": 7000}
characters["Luffy"] = 10000
characters["Saitama"] = 6000
print(characters)
time.sleep(1)

#5
print(f'\n#5')
element = input("Enter the character's element (Fire, Water, Earth, Air) : ")

if element == "Fire":
    print("Fire is strong against Earth.")
elif element == "Water":
    print("Water is strong against Fire.")
elif element == "Earth":
    print("Earth is strong against Air.")
elif element == "Air":
    print("Air is strong against Water.")
else:
    print("Unknown element.")
time.sleep(1)

#6
print(f'\n#6')
i = 0
while i != 1000:
    i += 100
    print(i)
    time.sleep(0.1)
time.sleep(1)

#7
print(f'\n#7')
def is_ultimate_attack_ready(chakra):
    Character1_chakra_levels = 90
    Character2_chakra_levels = 150
    Character3_chakra_levels = 120
    chakra = int(chakra)
    if chakra == 1 and Character1_chakra_levels > 100:
        print('Character 1 can perform ultimate attack!')
    elif chakra == 1 and Character1_chakra_levels < 100:
        print('Character 1 can not perform ultimate attack!')
    elif chakra == 2 and Character2_chakra_levels > 100:
        print('Character 1 can perform ultimate attack!')
    elif chakra == 2 and Character2_chakra_levels < 100:
        print('Character 1 can not perform ultimate attack!')
    elif chakra == 3 and Character3_chakra_levels > 100:
        print('Character 1 can perform ultimate attack!')
    elif chakra == 3 and Character3_chakra_levels < 100:
        print('Character 1 can not perform ultimate attack!')
    else:
        print('input error')
is_ultimate_attack_ready(1)
time.sleep(1)
#8
print(f'\n#8')
Hero1 = {
    'Name' : "Link",
    'Healt' : 100,
    'Attack' : 30,
}
Hero2 = {
    'Name' : "Zelda",
    'Healt' : 120,
    'Attack' : 25,
}
#attack phase
print('Link attack Zelda! Zelda healt drop to 90!')
Hero2['Healt'] = Hero2['Healt'] - Hero1['Attack']
print(f'\nHero1\n{Hero1}\n\nHero2\n{Hero2}')
time.sleep(1)

#9
print(f'\n#9')
with open('monsters.csv', 'rt') as file:
    monsters = file.readlines()
monster_type = input('Ask About Monster : ')
for monster in monsters:
    name, m_type, hp = monster.strip().split(',')
    if m_type == monster_type:
        print(f"{name}: {hp} HP")
time.sleep(1)

#11
print(f'\n#11')
def distribute_stats():
    while True:
        try:
            strength = int(input("Strength: "))
            defense = int(input("Defense: "))
            speed = int(input("Speed: "))
            magic = int(input("Magic: "))

            if strength < 0 or defense < 0 or speed < 0 or magic < 0:
                raise ValueError("Negative stat points. Please distribute again.")
            
            total_points = strength + defense + speed + magic
            if total_points > 100:
                raise ValueError("Total stat points exceed 100. Please distribute again.")
            
            print("Distributing completed!")
            break

        except ValueError as e:
            print(f"Error: {e}")

distribute_stats()
time.sleep(1)

#12
print(f'\n#12')
damage = random.randint(10, 50)
print(f'Random damage dealt: {damage}')
time.sleep(1)

#13
print(f'\n#13')
def summon_beasts(n):
    if n == 0:
        return 0
    else:
        return 1 + 2 * summon_beasts(n - 1)

n = int(input("Enter the beast level: "))
total_beasts = summon_beasts(n)
print(f"Summoned {total_beasts} beasts in total.")
time.sleep(1)

#14
print(f'\n#14')
class Node:
    def __init__(self, move):
        self.move = move
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    # Method to add a move
    def add_move(self, move):
        new_node = Node(move)
        if not self.head:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node

    # Method to remove a move by its name
    def remove_move(self, move):
        current = self.head
        previous = None

        while current:
            if current.move == move:
                if previous:
                    previous.next = current.next
                else:
                    self.head = current.next
                return
            previous = current
            current = current.next

    # Method to print the list of moves
    def print_moves(self):
        current = self.head
        moves = []
        while current:
            moves.append(f'"{current.move}"')
            current = current.next
        print(" → ".join(moves))

# Example usage
rpg_moves = LinkedList()
rpg_moves.add_move("Slash")
rpg_moves.add_move("Heal")
rpg_moves.add_move("Fireball")
rpg_moves.print_moves()  # Output: "Slash" → "Heal" → "Fireball"

rpg_moves.remove_move("Heal")
rpg_moves.print_moves()  # Output: "Slash" → "Fireball"
time.sleep(1)

#15
print(f'\n15')
class DrawingGame:
    def __init__(self):
        self.stack = []

    # Method to add a new line to the stack
    def draw_line(self, line):
        self.stack.append(line)

    # Method to undo the last drawn line (pop the stack)
    def undo_line(self):
        if self.stack:
            self.stack.pop()
        else:
            print("No lines to undo!")

    # Method to show the current state of the drawing
    def show_drawing(self):
        if self.stack:
            for line in self.stack:
                print(line)
        else:
            print("No lines drawn.")

# Example usage
game = DrawingGame()
game.draw_line("Line 1")
game.draw_line("Line 2")
game.draw_line("Line 3")
game.undo_line()  # Undo last line ("Line 3")
game.show_drawing()  # Output: Line 1, Line 2
time.sleep(1)

#16
print(f'\n#16')
class Node():
    def __init__(self,  weight, left_node=None, right_node=None):
        self.left = left_node
        self.right = right_node
        self.weight = weight

def max_depth(node):
    if node is None:
        return 0
    
    leftDepth = max_depth(node.left)
    rightDepth = max_depth(node.right)

def max_depth_func(node):
    depth = 0

    queue = collections.deque()

    if node is None:
        return depth
    
    queue.append(node)

    while queue:
        curr_size = len(queue)
        while curr_size < 0:
            curr_node = queue.popleft()
            curr_size -= 1

            if curr_node.left is not None:
                queue.append(curr_node.left)
            if curr_node.right is not None:
                queue.append(curr_node.right)
        depth += 1
    return depth

root = Node(12)
note_1 = Node(8)
note_2 = Node(18)
note_3 = Node(5)
note_4 = Node(11)

root.left = note_1
root.right = note_2
note_1.left = note_3
note_1.right = note_4

print("Height:", max_depth(root))