Study Room 04
>| 57066 => Tapatsatorn Kusolsak
>| 57528 => Phongsapak Sutijannapa