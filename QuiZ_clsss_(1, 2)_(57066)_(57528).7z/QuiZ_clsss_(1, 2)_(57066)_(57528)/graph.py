def print_graph(v, edges):
    adjacency_dict = {}
    for edge in edges:
        source_edge = edge[0]
        adjency_edge = str(edge[1])
        try:
            adjacency_dict[source_edge]
        except KeyError:
            adjacency_dict[source_edge] = []
        adjacency_dict[source_edge].append(adjency_edge)

    for k, v in adjacency_dict.items():
        '''output = f'{k} -> {' '.join(str(v))}'
        print(output)'''
        print(f'{k} - > {' '.join(v)}')

if __name__ == '__main__':
    v = 3
    edges = ((0, 1), (1, 2), (2, 3), (3, 0), (1, 3))
    print_graph(v, edges)